CREATE DATABASE IF NOT EXISTS function_hall_booking;
USE function_hall_booking;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS food_packages;
DROP TABLE IF EXISTS decorations;
DROP TABLE IF EXISTS halls;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE halls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    location VARCHAR(200) NOT NULL,
    capacity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(500),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE decorations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE food_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price_per_person DECIMAL(10,2) NOT NULL,
    image VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    hall_id INT NOT NULL,
    decoration_id INT NULL,
    food_id INT NULL,
    event_date DATE NOT NULL,
    guest_count INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending','Confirmed','Cancelled','Completed') NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_booking_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_booking_hall
        FOREIGN KEY (hall_id) REFERENCES halls(id)
        ON DELETE RESTRICT,

    CONSTRAINT fk_booking_decoration
        FOREIGN KEY (decoration_id) REFERENCES decorations(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_booking_food
        FOREIGN KEY (food_id) REFERENCES food_packages(id)
        ON DELETE SET NULL
);

INSERT INTO halls (name, location, capacity, price, image, description) VALUES
('Royal Grand Function Hall', 'Tirupati', 500, 45000,
 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1000&q=80',
 'Spacious hall suitable for weddings, receptions and large celebrations.'),

('Green Palace Hall', 'Nellore', 300, 30000,
 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1000&q=80',
 'Elegant function hall with comfortable seating and dining facilities.'),

('Pearl Celebration Hall', 'Chennai', 200, 22000,
 'https://images.unsplash.com/photo-1507504031003-b417219a0fde?auto=format&fit=crop&w=1000&q=80',
 'Modern hall for birthdays, engagements and smaller functions.');

INSERT INTO decorations (name, description, price, image) VALUES
('Royal Wedding Decor', 'Flowers, stage decoration, entrance decoration and lighting.', 25000,
 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1000&q=80'),
('Birthday Theme Decor', 'Colorful balloon and theme decoration with backdrop.', 10000,
 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1000&q=80'),
('Classic Floral Decor', 'Elegant floral decoration for a traditional celebration.', 15000,
 'https://images.unsplash.com/photo-1478146896981-b80fe463b330?auto=format&fit=crop&w=1000&q=80');

INSERT INTO food_packages (name, description, price_per_person, image) VALUES
('Basic Veg Package', 'Rice, curry, dal, vegetables, sweet and beverage.', 250,
 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1000&q=80'),
('Premium Veg Package', 'Starter, rice, biryani, curries, bread, sweets and beverages.', 450,
 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=1000&q=80'),
('Deluxe Mixed Package', 'Starters, biryani, vegetarian dishes, non-vegetarian dish, desserts and beverages.', 650,
 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=1000&q=80');

-- Demo admin:
-- password is Admin@123
-- bcrypt hash generated for Admin@123
INSERT INTO users (name, email, phone, password, role)
VALUES (
    'System Admin',
    'admin@functionhall.com',
    '9999999999',
    '$2b$10$8vJ9YQm5qKJv2hX0Qq7x.Oe0M6b8zL7jY7mWn6QyQ9f7k6jQY0Q2',
    'admin'
);
