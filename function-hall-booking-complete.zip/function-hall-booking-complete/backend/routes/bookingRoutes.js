const express = require("express");
const controller = require("../controllers/bookingController");

const router = express.Router();

router.post("/", controller.createBooking);
router.get("/user/:userId", controller.getUserBookings);
router.get("/", controller.getAllBookings);
router.patch("/:id/status", controller.updateStatus);
router.patch("/:id/cancel", controller.cancelBooking);

module.exports = router;
