const express = require("express");
const controller = require("../controllers/hallController");

const router = express.Router();

router.get("/", controller.getHalls);
router.get("/:id", controller.getHall);
router.post("/", controller.createHall);

module.exports = router;
