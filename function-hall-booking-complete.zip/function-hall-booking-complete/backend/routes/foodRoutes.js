const express = require("express");
const controller = require("../controllers/foodController");

const router = express.Router();

router.get("/", controller.getFood);
router.post("/", controller.createFood);

module.exports = router;
