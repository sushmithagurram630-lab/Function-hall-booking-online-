const express = require("express");
const controller = require("../controllers/decorationController");

const router = express.Router();

router.get("/", controller.getDecorations);
router.post("/", controller.createDecoration);

module.exports = router;
