const db = require("../config/database");

async function getAll() {
    const [rows] = await db.execute(
        "SELECT * FROM food_packages ORDER BY id DESC"
    );
    return rows;
}

async function getById(id) {
    const [rows] = await db.execute(
        "SELECT * FROM food_packages WHERE id = ?",
        [id]
    );
    return rows[0];
}

async function create(data) {
    const [result] = await db.execute(
        `INSERT INTO food_packages
        (name, description, price_per_person, image)
        VALUES (?, ?, ?, ?)`,
        [
            data.name,
            data.description || "",
            data.price_per_person,
            data.image || ""
        ]
    );
    return result.insertId;
}

module.exports = { getAll, getById, create };
