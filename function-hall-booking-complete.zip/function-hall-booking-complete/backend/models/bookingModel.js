const db = require("../config/database");

async function isHallBooked(hallId, eventDate) {
    const [rows] = await db.execute(
        `SELECT id FROM bookings
         WHERE hall_id = ?
         AND event_date = ?
         AND status <> 'Cancelled'`,
        [hallId, eventDate]
    );
    return rows.length > 0;
}

async function create(data) {
    const [result] = await db.execute(
        `INSERT INTO bookings
        (user_id, hall_id, decoration_id, food_id, event_date,
         guest_count, total_amount, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')`,
        [
            data.user_id,
            data.hall_id,
            data.decoration_id || null,
            data.food_id || null,
            data.event_date,
            data.guest_count,
            data.total_amount
        ]
    );
    return result.insertId;
}

async function getByUser(userId) {
    const [rows] = await db.execute(
        `SELECT
            b.*,
            h.name AS hall_name,
            h.location AS hall_location,
            d.name AS decoration_name,
            f.name AS food_name
         FROM bookings b
         JOIN halls h ON b.hall_id = h.id
         LEFT JOIN decorations d ON b.decoration_id = d.id
         LEFT JOIN food_packages f ON b.food_id = f.id
         WHERE b.user_id = ?
         ORDER BY b.created_at DESC`,
        [userId]
    );
    return rows;
}

async function getAll() {
    const [rows] = await db.execute(
        `SELECT
            b.*,
            u.name AS user_name,
            u.email AS user_email,
            u.phone AS user_phone,
            h.name AS hall_name,
            d.name AS decoration_name,
            f.name AS food_name
         FROM bookings b
         JOIN users u ON b.user_id = u.id
         JOIN halls h ON b.hall_id = h.id
         LEFT JOIN decorations d ON b.decoration_id = d.id
         LEFT JOIN food_packages f ON b.food_id = f.id
         ORDER BY b.created_at DESC`
    );
    return rows;
}

async function updateStatus(id, status) {
    const [result] = await db.execute(
        "UPDATE bookings SET status = ? WHERE id = ?",
        [status, id]
    );
    return result.affectedRows;
}

async function cancelByUser(id, userId) {
    const [result] = await db.execute(
        `UPDATE bookings
         SET status = 'Cancelled'
         WHERE id = ? AND user_id = ?
         AND status <> 'Cancelled'`,
        [id, userId]
    );
    return result.affectedRows;
}

module.exports = {
    isHallBooked,
    create,
    getByUser,
    getAll,
    updateStatus,
    cancelByUser
};
