const db = require("../config/database");

async function getAll() {
    const [rows] = await db.execute(
        "SELECT * FROM decorations ORDER BY id DESC"
    );
    return rows;
}

async function getById(id) {
    const [rows] = await db.execute(
        "SELECT * FROM decorations WHERE id = ?",
        [id]
    );
    return rows[0];
}

async function create(data) {
    const [result] = await db.execute(
        `INSERT INTO decorations
        (name, description, price, image)
        VALUES (?, ?, ?, ?)`,
        [
            data.name,
            data.description || "",
            data.price,
            data.image || ""
        ]
    );
    return result.insertId;
}

module.exports = { getAll, getById, create };
