const db = require("../config/database");

async function getAll() {
    const [rows] = await db.execute(
        "SELECT * FROM halls ORDER BY id DESC"
    );
    return rows;
}

async function getById(id) {
    const [rows] = await db.execute(
        "SELECT * FROM halls WHERE id = ?",
        [id]
    );
    return rows[0];
}

async function create(data) {
    const [result] = await db.execute(
        `INSERT INTO halls
        (name, location, capacity, price, image, description)
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
            data.name,
            data.location,
            data.capacity,
            data.price,
            data.image || "",
            data.description || ""
        ]
    );
    return result.insertId;
}

module.exports = { getAll, getById, create };
