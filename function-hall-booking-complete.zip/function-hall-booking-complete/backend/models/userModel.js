const db = require("../config/database");

async function findByEmail(email) {
    const [rows] = await db.execute(
        "SELECT * FROM users WHERE email = ?",
        [email]
    );
    return rows[0];
}

async function findById(id) {
    const [rows] = await db.execute(
        "SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?",
        [id]
    );
    return rows[0];
}

async function createUser(name, email, phone, passwordHash) {
    const [result] = await db.execute(
        "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)",
        [name, email, phone, passwordHash]
    );
    return result.insertId;
}

module.exports = {
    findByEmail,
    findById,
    createUser
};
