const bcrypt = require("bcryptjs");
const userModel = require("../models/userModel");

async function register(req, res) {
    try {
        const { name, email, phone, password } = req.body;

        if (!name || !email || !phone || !password) {
            return res.status(400).json({
                message: "All fields are required."
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                message: "Password must contain at least 6 characters."
            });
        }

        const existing = await userModel.findByEmail(email);

        if (existing) {
            return res.status(409).json({
                message: "Email is already registered."
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);
        const id = await userModel.createUser(
            name,
            email,
            phone,
            passwordHash
        );

        res.status(201).json({
            message: "Registration successful.",
            userId: id
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Registration failed." });
    }
}

async function login(req, res) {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: "Email and password are required."
            });
        }

        const user = await userModel.findByEmail(email);

        if (!user) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        const valid = await bcrypt.compare(password, user.password);

        if (!valid) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        res.json({
            message: "Login successful.",
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Login failed." });
    }
}

async function profile(req, res) {
    try {
        const user = await userModel.findById(req.params.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found."
            });
        }

        res.json(user);
    } catch (error) {
        res.status(500).json({ message: "Could not load profile." });
    }
}

module.exports = {
    register,
    login,
    profile
};
