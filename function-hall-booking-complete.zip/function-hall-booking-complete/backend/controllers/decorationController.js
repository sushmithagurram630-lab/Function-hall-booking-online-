const decorationModel = require("../models/decorationModel");

async function getDecorations(req, res) {
    try {
        res.json(await decorationModel.getAll());
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not load decorations."
        });
    }
}

async function createDecoration(req, res) {
    try {
        const id = await decorationModel.create(req.body);
        res.status(201).json({
            message: "Decoration added successfully.",
            id
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not add decoration."
        });
    }
}

module.exports = {
    getDecorations,
    createDecoration
};
