const bookingModel = require("../models/bookingModel");
const hallModel = require("../models/hallModel");
const decorationModel = require("../models/decorationModel");
const foodModel = require("../models/foodModel");

async function createBooking(req, res) {
    try {
        const {
            user_id,
            hall_id,
            decoration_id,
            food_id,
            event_date,
            guest_count
        } = req.body;

        if (!user_id || !hall_id || !event_date || !guest_count) {
            return res.status(400).json({
                message: "User, hall, date and guest count are required."
            });
        }

        const guests = Number(guest_count);

        if (!Number.isInteger(guests) || guests <= 0) {
            return res.status(400).json({
                message: "Guest count must be a positive number."
            });
        }

        const hall = await hallModel.getById(hall_id);

        if (!hall) {
            return res.status(404).json({ message: "Hall not found." });
        }

        if (guests > hall.capacity) {
            return res.status(400).json({
                message: `This hall can accommodate only ${hall.capacity} guests.`
            });
        }

        const booked = await bookingModel.isHallBooked(
            hall_id,
            event_date
        );

        if (booked) {
            return res.status(409).json({
                message: "This hall is already booked for this date."
            });
        }

        let decoration = null;
        let food = null;

        if (decoration_id) {
            decoration = await decorationModel.getById(decoration_id);
            if (!decoration) {
                return res.status(404).json({
                    message: "Decoration not found."
                });
            }
        }

        if (food_id) {
            food = await foodModel.getById(food_id);
            if (!food) {
                return res.status(404).json({
                    message: "Food package not found."
                });
            }
        }

        const total =
            Number(hall.price) +
            (decoration ? Number(decoration.price) : 0) +
            (food ? Number(food.price_per_person) * guests : 0);

        const id = await bookingModel.create({
            user_id,
            hall_id,
            decoration_id: decoration_id || null,
            food_id: food_id || null,
            event_date,
            guest_count: guests,
            total_amount: total
        });

        res.status(201).json({
            message: "Booking created successfully.",
            bookingId: id,
            totalAmount: total
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not create booking."
        });
    }
}

async function getUserBookings(req, res) {
    try {
        const bookings = await bookingModel.getByUser(req.params.userId);
        res.json(bookings);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not load bookings."
        });
    }
}

async function getAllBookings(req, res) {
    try {
        res.json(await bookingModel.getAll());
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not load all bookings."
        });
    }
}

async function updateStatus(req, res) {
    try {
        const allowed = [
            "Pending",
            "Confirmed",
            "Cancelled",
            "Completed"
        ];

        const { status } = req.body;

        if (!allowed.includes(status)) {
            return res.status(400).json({
                message: "Invalid booking status."
            });
        }

        const affected = await bookingModel.updateStatus(
            req.params.id,
            status
        );

        if (!affected) {
            return res.status(404).json({
                message: "Booking not found."
            });
        }

        res.json({
            message: "Booking status updated."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not update booking."
        });
    }
}

async function cancelBooking(req, res) {
    try {
        const affected = await bookingModel.cancelByUser(
            req.params.id,
            req.body.user_id
        );

        if (!affected) {
            return res.status(404).json({
                message: "Booking not found or already cancelled."
            });
        }

        res.json({
            message: "Booking cancelled."
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not cancel booking."
        });
    }
}

module.exports = {
    createBooking,
    getUserBookings,
    getAllBookings,
    updateStatus,
    cancelBooking
};
