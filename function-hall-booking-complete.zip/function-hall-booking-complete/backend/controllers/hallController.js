const hallModel = require("../models/hallModel");

async function getHalls(req, res) {
    try {
        const halls = await hallModel.getAll();
        res.json(halls);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Could not load halls." });
    }
}

async function getHall(req, res) {
    try {
        const hall = await hallModel.getById(req.params.id);

        if (!hall) {
            return res.status(404).json({ message: "Hall not found." });
        }

        res.json(hall);
    } catch (error) {
        res.status(500).json({ message: "Could not load hall." });
    }
}

async function createHall(req, res) {
    try {
        const id = await hallModel.create(req.body);
        res.status(201).json({
            message: "Hall added successfully.",
            id
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Could not add hall." });
    }
}

module.exports = {
    getHalls,
    getHall,
    createHall
};
