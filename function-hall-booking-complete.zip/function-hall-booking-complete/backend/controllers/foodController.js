const foodModel = require("../models/foodModel");

async function getFood(req, res) {
    try {
        res.json(await foodModel.getAll());
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not load food packages."
        });
    }
}

async function createFood(req, res) {
    try {
        const id = await foodModel.create(req.body);
        res.status(201).json({
            message: "Food package added successfully.",
            id
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Could not add food package."
        });
    }
}

module.exports = {
    getFood,
    createFood
};
