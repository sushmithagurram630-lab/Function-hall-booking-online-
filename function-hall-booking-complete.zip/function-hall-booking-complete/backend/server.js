const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const authRoutes = require("./routes/authRoutes");
const hallRoutes = require("./routes/hallRoutes");
const decorationRoutes = require("./routes/decorationRoutes");
const foodRoutes = require("./routes/foodRoutes");
const bookingRoutes = require("./routes/bookingRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/halls", hallRoutes);
app.use("/api/decorations", decorationRoutes);
app.use("/api/food", foodRoutes);
app.use("/api/bookings", bookingRoutes);

// Frontend
const frontendPath = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendPath));

app.get("/", (req, res) => {
    res.sendFile(path.join(frontendPath, "index.html"));
});

// Basic error handler
app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).json({
        message: "Internal server error."
    });
});

app.listen(PORT, () => {
    console.log(`Function Hall Booking API running at http://localhost:${PORT}`);
});
