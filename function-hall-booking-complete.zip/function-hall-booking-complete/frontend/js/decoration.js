const API = "/api";

async function loadDecorations() {
    const container = document.getElementById("decorationList");

    try {
        const response = await fetch(`${API}/decorations`);
        const data = await response.json();

        container.innerHTML = data.map(item => `
            <div class="card">
                <img src="${item.image}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>${item.description || ""}</p>
                <p><strong>Price:</strong>
                    ₹${Number(item.price).toLocaleString("en-IN")}
                </p>
            </div>
        `).join("");
    } catch {
        container.innerHTML = "<p>Unable to load decorations.</p>";
    }
}

loadDecorations();
