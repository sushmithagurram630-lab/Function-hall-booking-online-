const API = "/api";

const user = JSON.parse(localStorage.getItem("user"));

if (!user) {
    alert("Please login before booking.");
    location.href = "login.html";
}

const hallSelect = document.getElementById("hallId");
const decorationSelect = document.getElementById("decorationId");
const foodSelect = document.getElementById("foodId");
const guestInput = document.getElementById("guestCount");
const dateInput = document.getElementById("eventDate");
const summary = document.getElementById("priceSummary");

const params = new URLSearchParams(location.search);
const selectedHallId = params.get("hallId");

let halls = [];
let decorations = [];
let foods = [];

function money(value) {
    return Number(value).toLocaleString("en-IN");
}

async function loadOptions() {
    const [hallResponse, decorationResponse, foodResponse] =
        await Promise.all([
            fetch(`${API}/halls`),
            fetch(`${API}/decorations`),
            fetch(`${API}/food`)
        ]);

    halls = await hallResponse.json();
    decorations = await decorationResponse.json();
    foods = await foodResponse.json();

    hallSelect.innerHTML = halls.map(h => `
        <option value="${h.id}">
            ${h.name} - ₹${money(h.price)}
        </option>
    `).join("");

    decorationSelect.innerHTML =
        `<option value="">No decoration</option>` +
        decorations.map(d => `
            <option value="${d.id}">
                ${d.name} - ₹${money(d.price)}
            </option>
        `).join("");

    foodSelect.innerHTML =
        `<option value="">No food package</option>` +
        foods.map(f => `
            <option value="${f.id}">
                ${f.name} - ₹${money(f.price_per_person)}/person
            </option>
        `).join("");

    if (selectedHallId) {
        hallSelect.value = selectedHallId;
    }

    updatePrice();
}

function updatePrice() {
    const hall = halls.find(h => String(h.id) === String(hallSelect.value));
    const decoration = decorations.find(
        d => String(d.id) === String(decorationSelect.value)
    );
    const food = foods.find(
        f => String(f.id) === String(foodSelect.value)
    );

    const guests = Number(guestInput.value) || 0;

    const hallPrice = hall ? Number(hall.price) : 0;
    const decorationPrice = decoration ? Number(decoration.price) : 0;
    const foodPrice = food
        ? Number(food.price_per_person) * guests
        : 0;

    const total = hallPrice + decorationPrice + foodPrice;

    summary.innerHTML = `
        <p>Hall: ₹${money(hallPrice)}</p>
        <p>Decoration: ₹${money(decorationPrice)}</p>
        <p>Food: ₹${money(foodPrice)}</p>
        <hr>
        <h3>Estimated Total: ₹${money(total)}</h3>
    `;
}

hallSelect.addEventListener("change", updatePrice);
decorationSelect.addEventListener("change", updatePrice);
foodSelect.addEventListener("change", updatePrice);
guestInput.addEventListener("input", updatePrice);

dateInput.min = new Date().toISOString().split("T")[0];

document.getElementById("bookingForm").addEventListener("submit", async event => {
    event.preventDefault();

    const message = document.getElementById("message");

    const body = {
        user_id: user.id,
        hall_id: Number(hallSelect.value),
        decoration_id: decorationSelect.value
            ? Number(decorationSelect.value)
            : null,
        food_id: foodSelect.value
            ? Number(foodSelect.value)
            : null,
        event_date: dateInput.value,
        guest_count: Number(guestInput.value)
    };

    try {
        const response = await fetch(`${API}/bookings`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });

        const result = await response.json();
        message.textContent = result.message;

        if (response.ok) {
            message.textContent +=
                ` Total: ₹${money(result.totalAmount)}`;

            setTimeout(() => {
                location.href = "my-bookings.html";
            }, 1200);
        }
    } catch {
        message.textContent =
            "Could not connect to the backend.";
    }
});

loadOptions().catch(() => {
    document.getElementById("message").textContent =
        "Could not load booking options.";
});
