const API = "/api";

async function loadHalls() {
    const container = document.getElementById("hallList");

    try {
        const response = await fetch(`${API}/halls`);
        const halls = await response.json();

        if (!halls.length) {
            container.innerHTML = "<p>No halls available.</p>";
            return;
        }

        container.innerHTML = halls.map(hall => `
            <div class="card">
                <img src="${hall.image}" alt="${hall.name}">
                <h3>${hall.name}</h3>
                <p>${hall.description || ""}</p>
                <p><strong>Location:</strong> ${hall.location}</p>
                <p><strong>Capacity:</strong> ${hall.capacity}</p>
                <p><strong>Price:</strong> ₹${Number(hall.price).toLocaleString("en-IN")}</p>
                <a class="btn" href="hall-details.html?id=${hall.id}">
                    View Details
                </a>
            </div>
        `).join("");
    } catch (error) {
        container.innerHTML =
            "<p>Could not connect to the backend.</p>";
    }
}

loadHalls();
