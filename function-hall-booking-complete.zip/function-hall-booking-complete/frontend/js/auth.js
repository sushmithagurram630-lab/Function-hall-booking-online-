const API = "/api";

const registerForm = document.getElementById("registerForm");
const loginForm = document.getElementById("loginForm");

if (registerForm) {
    registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const message = document.getElementById("message");

        const body = {
            name: document.getElementById("name").value.trim(),
            email: document.getElementById("email").value.trim(),
            phone: document.getElementById("phone").value.trim(),
            password: document.getElementById("password").value
        };

        const response = await fetch(`${API}/auth/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });

        const result = await response.json();
        message.textContent = result.message;

        if (response.ok) {
            registerForm.reset();
            setTimeout(() => {
                location.href = "login.html";
            }, 1000);
        }
    });
}

if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const message = document.getElementById("message");

        const body = {
            email: document.getElementById("email").value.trim(),
            password: document.getElementById("password").value
        };

        const response = await fetch(`${API}/auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(body)
        });

        const result = await response.json();
        message.textContent = result.message;

        if (response.ok) {
            localStorage.setItem("user", JSON.stringify(result.user));

            setTimeout(() => {
                location.href = result.user.role === "admin"
                    ? "admin.html"
                    : "index.html";
            }, 500);
        }
    });
}
