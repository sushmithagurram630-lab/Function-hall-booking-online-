const API = "/api";

async function loadFood() {
    const container = document.getElementById("foodList");

    try {
        const response = await fetch(`${API}/food`);
        const data = await response.json();

        container.innerHTML = data.map(item => `
            <div class="card">
                <img src="${item.image}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>${item.description || ""}</p>
                <p><strong>Per Person:</strong>
                    ₹${Number(item.price_per_person).toLocaleString("en-IN")}
                </p>
            </div>
        `).join("");
    } catch {
        container.innerHTML = "<p>Unable to load food packages.</p>";
    }
}

loadFood();
