const API = "/api";

const user = JSON.parse(localStorage.getItem("user"));

if (!user || user.role !== "admin") {
    document.getElementById("accessMessage").innerHTML = `
        <div class="card">
            <h2>Admin access required</h2>
            <p>Please login using an admin account.</p>
            <a class="btn" href="login.html">Login</a>
        </div>
    `;
} else {
    document.getElementById("adminContent").classList.remove("hidden");
    loadBookings();
}

function logout() {
    localStorage.removeItem("user");
    location.href = "index.html";
}

async function sendForm(url, body, message) {
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
    });

    const result = await response.json();
    alert(result.message || message);

    if (response.ok) {
        location.reload();
    }
}

document.getElementById("hallForm")?.addEventListener("submit", event => {
    event.preventDefault();

    sendForm(`${API}/halls`, {
        name: document.getElementById("hallName").value,
        location: document.getElementById("hallLocation").value,
        capacity: Number(document.getElementById("hallCapacity").value),
        price: Number(document.getElementById("hallPrice").value),
        image: document.getElementById("hallImage").value,
        description: document.getElementById("hallDescription").value
    }, "Hall added.");
});

document.getElementById("decorationForm")?.addEventListener("submit", event => {
    event.preventDefault();

    sendForm(`${API}/decorations`, {
        name: document.getElementById("decName").value,
        price: Number(document.getElementById("decPrice").value),
        image: document.getElementById("decImage").value,
        description: document.getElementById("decDescription").value
    }, "Decoration added.");
});

document.getElementById("foodForm")?.addEventListener("submit", event => {
    event.preventDefault();

    sendForm(`${API}/food`, {
        name: document.getElementById("foodName").value,
        price_per_person: Number(document.getElementById("foodPrice").value),
        image: document.getElementById("foodImage").value,
        description: document.getElementById("foodDescription").value
    }, "Food package added.");
});

async function loadBookings() {
    const response = await fetch(`${API}/bookings`);
    const bookings = await response.json();

    const container = document.getElementById("allBookings");

    if (!bookings.length) {
        container.innerHTML = "<p>No bookings found.</p>";
        return;
    }

    container.innerHTML = `
        <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Hall</th>
                    <th>Date</th>
                    <th>Guests</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${bookings.map(b => `
                    <tr>
                        <td>${b.id}</td>
                        <td>
                            ${b.user_name}<br>
                            ${b.user_email}
                        </td>
                        <td>${b.hall_name}</td>
                        <td>${b.event_date}</td>
                        <td>${b.guest_count}</td>
                        <td>₹${Number(b.total_amount).toLocaleString("en-IN")}</td>
                        <td>
                            <select class="small-select"
                                onchange="updateStatus(${b.id}, this.value)">
                                ${["Pending","Confirmed","Cancelled","Completed"]
                                    .map(status => `
                                        <option value="${status}"
                                            ${status === b.status ? "selected" : ""}>
                                            ${status}
                                        </option>
                                    `).join("")}
                            </select>
                        </td>
                    </tr>
                `).join("")}
            </tbody>
        </table>
        </div>
    `;
}

async function updateStatus(id, status) {
    const response = await fetch(`${API}/bookings/${id}/status`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ status })
    });

    const result = await response.json();
    alert(result.message);
    loadBookings();
}
