const API = "/api";

function getUser() {
    try {
        return JSON.parse(localStorage.getItem("user"));
    } catch {
        return null;
    }
}

function logout() {
    localStorage.removeItem("user");
    location.href = "index.html";
}

document.addEventListener("DOMContentLoaded", () => {
    const user = getUser();
    const loginLink = document.getElementById("loginLink");
    const logoutBtn = document.getElementById("logoutBtn");

    if (user && loginLink) {
        loginLink.textContent = user.role === "admin"
            ? "Admin"
            : user.name;
        loginLink.href = user.role === "admin"
            ? "admin.html"
            : "my-bookings.html";
    }

    if (user && logoutBtn) {
        logoutBtn.classList.remove("hidden");
        logoutBtn.addEventListener("click", logout);
    }
});
